﻿namespace WeatherFormApp
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.city_lb = new System.Windows.Forms.Label();
            this.temp_lb = new System.Windows.Forms.Label();
            this.humid_lb = new System.Windows.Forms.Label();
            this.pressure_lb = new System.Windows.Forms.Label();
            this.rain_lb = new System.Windows.Forms.Label();
            this.recommend_lb = new System.Windows.Forms.Label();
            this.city_tb = new System.Windows.Forms.TextBox();
            this.temp_tb = new System.Windows.Forms.TextBox();
            this.humid_tb = new System.Windows.Forms.TextBox();
            this.pressure_tb = new System.Windows.Forms.TextBox();
            this.rain_tb = new System.Windows.Forms.TextBox();
            this.recommend_tb = new System.Windows.Forms.TextBox();
            this.search_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // city_lb
            // 
            this.city_lb.AutoSize = true;
            this.city_lb.Location = new System.Drawing.Point(41, 28);
            this.city_lb.Name = "city_lb";
            this.city_lb.Size = new System.Drawing.Size(141, 20);
            this.city_lb.TabIndex = 0;
            this.city_lb.Text = "Название города";
            // 
            // temp_lb
            // 
            this.temp_lb.AutoSize = true;
            this.temp_lb.Location = new System.Drawing.Point(18, 185);
            this.temp_lb.Name = "temp_lb";
            this.temp_lb.Size = new System.Drawing.Size(108, 20);
            this.temp_lb.TabIndex = 1;
            this.temp_lb.Text = "Температура";
            // 
            // humid_lb
            // 
            this.humid_lb.AutoSize = true;
            this.humid_lb.Location = new System.Drawing.Point(18, 217);
            this.humid_lb.Name = "humid_lb";
            this.humid_lb.Size = new System.Drawing.Size(94, 20);
            this.humid_lb.TabIndex = 2;
            this.humid_lb.Text = "Влажность";
            // 
            // pressure_lb
            // 
            this.pressure_lb.AutoSize = true;
            this.pressure_lb.Location = new System.Drawing.Point(18, 249);
            this.pressure_lb.Name = "pressure_lb";
            this.pressure_lb.Size = new System.Drawing.Size(85, 20);
            this.pressure_lb.TabIndex = 3;
            this.pressure_lb.Text = "Давление";
            // 
            // rain_lb
            // 
            this.rain_lb.AutoSize = true;
            this.rain_lb.Location = new System.Drawing.Point(18, 281);
            this.rain_lb.Name = "rain_lb";
            this.rain_lb.Size = new System.Drawing.Size(66, 20);
            this.rain_lb.TabIndex = 4;
            this.rain_lb.Text = "Осадки";
            // 
            // recommend_lb
            // 
            this.recommend_lb.AutoSize = true;
            this.recommend_lb.Location = new System.Drawing.Point(18, 313);
            this.recommend_lb.Name = "recommend_lb";
            this.recommend_lb.Size = new System.Drawing.Size(121, 20);
            this.recommend_lb.TabIndex = 5;
            this.recommend_lb.Text = "Рекомендации";
            // 
            // city_tb
            // 
            this.city_tb.Location = new System.Drawing.Point(45, 51);
            this.city_tb.Name = "city_tb";
            this.city_tb.Size = new System.Drawing.Size(385, 26);
            this.city_tb.TabIndex = 6;
            this.city_tb.Text = "Санкт-Петербург";
            // 
            // temp_tb
            // 
            this.temp_tb.Location = new System.Drawing.Point(145, 182);
            this.temp_tb.Name = "temp_tb";
            this.temp_tb.ReadOnly = true;
            this.temp_tb.Size = new System.Drawing.Size(166, 26);
            this.temp_tb.TabIndex = 7;
            // 
            // humid_tb
            // 
            this.humid_tb.Location = new System.Drawing.Point(145, 214);
            this.humid_tb.Name = "humid_tb";
            this.humid_tb.ReadOnly = true;
            this.humid_tb.Size = new System.Drawing.Size(166, 26);
            this.humid_tb.TabIndex = 8;
            // 
            // pressure_tb
            // 
            this.pressure_tb.Location = new System.Drawing.Point(145, 246);
            this.pressure_tb.Name = "pressure_tb";
            this.pressure_tb.ReadOnly = true;
            this.pressure_tb.Size = new System.Drawing.Size(166, 26);
            this.pressure_tb.TabIndex = 9;
            // 
            // rain_tb
            // 
            this.rain_tb.Location = new System.Drawing.Point(145, 278);
            this.rain_tb.Name = "rain_tb";
            this.rain_tb.ReadOnly = true;
            this.rain_tb.Size = new System.Drawing.Size(285, 26);
            this.rain_tb.TabIndex = 10;
            // 
            // recommend_tb
            // 
            this.recommend_tb.Location = new System.Drawing.Point(145, 310);
            this.recommend_tb.Name = "recommend_tb";
            this.recommend_tb.ReadOnly = true;
            this.recommend_tb.Size = new System.Drawing.Size(285, 26);
            this.recommend_tb.TabIndex = 11;
            // 
            // search_btn
            // 
            this.search_btn.Location = new System.Drawing.Point(145, 83);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(166, 54);
            this.search_btn.TabIndex = 12;
            this.search_btn.Text = "Узнать прогноз";
            this.search_btn.UseVisualStyleBackColor = true;
            this.search_btn.Click += new System.EventHandler(this.search_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.Location = new System.Drawing.Point(130, 360);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(166, 54);
            this.save_btn.TabIndex = 13;
            this.save_btn.Text = "Сохранить данные";
            this.save_btn.UseVisualStyleBackColor = true;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 426);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.recommend_tb);
            this.Controls.Add(this.rain_tb);
            this.Controls.Add(this.pressure_tb);
            this.Controls.Add(this.humid_tb);
            this.Controls.Add(this.temp_tb);
            this.Controls.Add(this.city_tb);
            this.Controls.Add(this.recommend_lb);
            this.Controls.Add(this.rain_lb);
            this.Controls.Add(this.pressure_lb);
            this.Controls.Add(this.humid_lb);
            this.Controls.Add(this.temp_lb);
            this.Controls.Add(this.city_lb);
            this.Name = "Form1";
            this.Text = "Погода в Санкт-Петербурге";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label city_lb;
        private System.Windows.Forms.Label temp_lb;
        private System.Windows.Forms.Label humid_lb;
        private System.Windows.Forms.Label pressure_lb;
        private System.Windows.Forms.Label rain_lb;
        private System.Windows.Forms.Label recommend_lb;
        private System.Windows.Forms.TextBox city_tb;
        private System.Windows.Forms.TextBox temp_tb;
        private System.Windows.Forms.TextBox humid_tb;
        private System.Windows.Forms.TextBox pressure_tb;
        private System.Windows.Forms.TextBox rain_tb;
        private System.Windows.Forms.TextBox recommend_tb;
        private System.Windows.Forms.Button search_btn;
        private System.Windows.Forms.Button save_btn;
    }
}

