﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using Newtonsoft.Json;
using System.IO;

namespace WeatherFormApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void getWeather()
        {
            dynamic info;
            using (WebClient web = new WebClient { Encoding = Encoding.UTF8 })
            {
                string url = "https://api.openweathermap.org/data/2.5/weather?q=Санкт-Петербург&appid=d397a995d6b587ba479889ad3dc3cf56&lang=ru&units=metric";
                var json = web.DownloadString(url);
                info = JsonConvert.DeserializeObject(json);
            }
            temp_tb.Text = info.main.temp + " градусов";
            humid_tb.Text = info.main.humidity + "%";
            pressure_tb.Text = Math.Round(Convert.ToDouble(info.main.pressure) * 0.750062, 2) + " мм рт. ст.";
            rain_tb.Text = info.weather[0].description;
            recommend_tb.Text = "super";
        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            switch (city_tb.Text)
            {
                case "Санкт-Петербург":
                    getWeather(); break;
                case "Питер":
                    getWeather(); break;
                case "СПб":
                    getWeather(); break;
                default:
                    MessageBox.Show("Неправильно введено название города", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); break;
            }

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Действительно ли вы планируете закрыть программу? Несохраненные данные будут потеряны", "Закрытие программы", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                e.Cancel = true;
            }
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Вы собираетесь сохранить данные в файл, путь которого выглядит вот так: " + Environment.CurrentDirectory + "\\data.csv \n Вы уверены, что хотите продложить?", "Сохпранение файла", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string csv = String.Join(",", "Санкт-Петербург", temp_tb.Text, humid_tb.Text, pressure_tb.Text, rain_tb.Text);
                File.WriteAllText(Environment.CurrentDirectory + "\\data.csv", csv);
            }
        }
    }
}
